# TopTop v1.1 — TikTok theo chuyên đề + LIVE

## Có gì mới
- Đổi tên ứng dụng thành **TopTop**.
- Hai khu riêng: **Chuyên đề** và **LIVE**.
- Video thường: lưu link TikTok theo chuyên đề, vuốt dọc bằng TikTok Embed Player.
- LIVE: lưu link `https://www.tiktok.com/@username/live`, mở nhanh bằng TikTok hoặc trình duyệt.
- Chia sẻ link từ TikTok sang TopTop: app tự nhận video thường hay LIVE.
- Link rút gọn `vt.tiktok.com` được APK thử follow redirect trước khi phân loại.
- Dữ liệu v1.0 cũ được migrate khi cài đè.

## Vì sao LIVE chưa phát trực tiếp bên trong TopTop?
TikTok có tài liệu Embed Player chính thức cho TikTok post/video ID, nhưng không có LIVE embed công khai tương đương được tài liệu hóa. Vì vậy v1.1 ưu tiên cách ổn định: TopTop quản lý danh sách LIVE và mở phiên LIVE bằng TikTok/trình duyệt.

## Affiliate
Chưa làm trong bản này theo yêu cầu. Sẽ để cho bản sau.
