# TopTop v2.3 — Embedded TikTok Feed

Bản 2.3 đổi kiến trúc sau khi TikTok Web không cho TopTop trích danh sách video ổn định.

Luồng mới:
1. Người dùng đăng nhập TikTok Web một lần trong TopTop.
2. Chọn chuyên đề.
3. TopTop mở TikTok Web Search theo chuyên đề NGAY BÊN TRONG ứng dụng.
4. TopTop thử tự mở video đầu tiên trong kết quả.
5. Nếu TikTok không cho tự mở, kết quả search vẫn hiển thị trong TopTop để người dùng chạm vào video.
6. Các deep-link mở app TikTok như intent://, tiktok://, snssdk://, market:// bị chặn.
7. LIVE mở TikTok LIVE trong chính TopTop.

Không còn:
- nhập link video;
- scrape danh sách video rồi dựng feed riêng;
- màn hình lỗi "TikTok chưa trả danh sách".

Danh mục:
LIVE, Công nghệ, Sức khỏe, Mẹo vặt, Đời sống, Tin tức,
Nhạc trẻ, Nhạc Bolero, Ẩm thực, Du lịch, Review - Phim ngắn,
Thiếu nhi, Hài hước.

Giới hạn:
TikTok không cung cấp public commercial API cho For You/Search feed tùy ý.
TopTop v2.3 dùng TikTok Web đã đăng nhập trong WebView, nên hành vi cuối cùng vẫn phụ thuộc TikTok Web.
