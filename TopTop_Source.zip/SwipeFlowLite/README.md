# TopTop v2.2 — TikTok Session Login

Thay đổi chính:
- Lần đầu mở TopTop, người dùng phải đăng nhập TikTok trong WebView TikTok bên trong app.
- TopTop không nhận/lưu username hoặc password. Người dùng nhập trực tiếp trên trang tiktok.com.
- WebView giữ cookie phiên TikTok trên thiết bị.
- Khi phiên còn hợp lệ, lần mở app sau vào thẳng màn hình chuyên đề.
- Có nút Đổi tài khoản để xóa cookie TikTok và đăng nhập lại.
- Khi chọn chuyên đề, TopTop dùng TikTok Web với phiên đã đăng nhập để tìm video public.
- Sau khi lấy được video ID, app dựng feed dọc ngay trong TopTop bằng TikTok Embed Player.
- Chặn intent://, tiktok://, snssdk://, market:// để không tự nhảy sang app TikTok.
- LIVE mở TikTok Live bên trong TopTop bằng cùng phiên đăng nhập.

Danh mục:
LIVE, Công nghệ, Sức khỏe, Mẹo vặt, Đời sống, Tin tức,
Nhạc trẻ, Nhạc Bolero, Ẩm thực, Du lịch, Review - Phim ngắn,
Thiếu nhi, Hài hước.

Giới hạn:
- Đây KHÔNG phải TikTok Login Kit/OAuth API chính thức vì bản test chưa có TikTok Developer Client Key.
- Đây là đăng nhập trực tiếp vào tiktok.com trong WebView và dùng cookie phiên trên máy.
- TikTok không có public API thương mại cho For You feed cá nhân hóa của tài khoản.
- Search/discovery vẫn phụ thuộc TikTok Web DOM; TikTok thay đổi web thì TopTop có thể cần cập nhật.

## v2.2.1 Login Hotfix
- Replaces the generic TikTok login entry with direct phone/email/username login flows.
- Avoids the “Use TikTok app” path because TopTop needs a WebView session cookie for its current discovery architecture.
- Hides native-app launch buttons where possible.
- Google/Facebook embedded sign-in may be blocked by their own OAuth policies; phone/email/username is the recommended test path.
