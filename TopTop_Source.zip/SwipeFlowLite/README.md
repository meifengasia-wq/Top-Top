# TopTop v2.1 — Stay-In-App Feed

Mục tiêu bản vá này:
- Không tự mở ứng dụng TikTok khi chọn chuyên đề.
- Không yêu cầu người dùng nhập từng link.
- TopTop dùng một WebView TikTok ẩn để tìm các video public theo chuyên đề.
- Sau khi lấy được video ID, app trở về giao diện TopTop và phát video bằng TikTok Embed Player.
- LIVE và fallback TikTok Web vẫn mở BÊN TRONG TopTop.
- Các deep-link như intent://, tiktok://, snssdk:// và market:// bị chặn để không nhảy sang app TikTok.

Danh mục:
LIVE, Công nghệ, Sức khỏe, Mẹo vặt, Đời sống, Tin tức,
Nhạc trẻ, Nhạc Bolero, Ẩm thực, Du lịch, Review - Phim ngắn,
Thiếu nhi, Hài hước.

Giới hạn:
TikTok không cung cấp một public feed/search API thương mại tự do cho kiểu ứng dụng này.
Cơ chế discovery của v2.1 dựa vào TikTok Web public. Nếu TikTok thay đổi DOM, chặn WebView,
hoặc bắt đăng nhập, discovery có thể thất bại. Khi đó TopTop chỉ cho fallback xem TikTok Web
ngay trong app và vẫn chặn việc tự mở ứng dụng TikTok.

Launcher icon vẫn dùng ảnh TopTop do người dùng cung cấp.
