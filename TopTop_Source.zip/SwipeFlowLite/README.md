# TopTop v2.0 — Guest Feed

Mục tiêu:
- Mở app -> chọn chuyên đề -> vào nội dung TikTok công khai ngay.
- Không nhập link.
- Không cần tài khoản TopTop.
- LIVE là mục riêng.
- Icon launcher lấy từ ảnh TopTop do người dùng cung cấp.

Danh mục:
LIVE, Công nghệ, Sức khỏe, Mẹo vặt, Đời sống, Tin tức,
Nhạc trẻ, Nhạc Bolero, Ẩm thực, Du lịch, Review - Phim ngắn,
Thiếu nhi, Hài hước.

Cách hoạt động:
- Chuyên đề mở TikTok Web Search công khai trong WebView.
- TopTop thử tự mở video công khai đầu tiên trong kết quả để vào viewer nhanh hơn.
- LIVE mở trang TikTok LIVE công khai.
- Sau đó trải nghiệm xem/đi tiếp phụ thuộc TikTok Web tại thời điểm chạy.
- TikTok có thể yêu cầu đăng nhập đối với một số nội dung/phiên; TopTop không vượt qua hạn chế đó.

Lưu ý:
TikTok không cung cấp API thương mại công khai tương đương một "For You/Search feed API"
cho app bên thứ ba tùy ý lấy mọi video theo chủ đề. Vì vậy v2.0 là bản thử Guest Feed dựa
trên TikTok Web công khai, không phải crawler và không bóc luồng video.
