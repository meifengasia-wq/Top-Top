# TopTop v2.4 FINAL — Public TikTok Web

Đây là bản thử cuối của hướng TikTok-as-source.

Thay đổi:
- Bỏ hoàn toàn đăng nhập bắt buộc.
- Bỏ hoàn toàn nhập link.
- Bỏ hoàn toàn scrape danh sách video để dựng feed riêng.
- Chọn chuyên đề -> TopTop mở trang TikTok hashtag công khai ngay trong WebView.
- TopTop thử tự mở video đầu tiên.
- Nếu hashtag không có video DOM, TopTop tự fallback sang TikTok Search.
- LIVE mở TikTok LIVE trong TopTop.
- Chặn deep-link intent://, tiktok://, snssdk://, market:// để không tự nhảy sang app TikTok.
- Giữ launcher icon TopTop hiện tại.

Mục tiêu là giảm tối đa các lớp dễ hỏng. TikTok Web vẫn là bên render nội dung.
Nếu TikTok chặn WebView/hashtag/search thì app không có public commercial API khác để thay thế.

Danh mục:
LIVE, Công nghệ, Sức khỏe, Mẹo vặt, Đời sống, Tin tức,
Nhạc trẻ, Nhạc Bolero, Ẩm thực, Du lịch, Review - Phim ngắn,
Thiếu nhi, Hài hước.


## v2.4.1 build hotfix
- Added the missing `android.webkit.JavascriptInterface` import required by `@JavascriptInterface` methods in `HomeBridge`.
