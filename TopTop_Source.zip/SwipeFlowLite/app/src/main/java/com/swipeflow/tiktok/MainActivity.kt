package com.swipeflow.tiktok

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONTokener
import org.json.JSONObject
import java.net.URLEncoder

class MainActivity : Activity() {

    private enum class BrowserMode { NONE, DISCOVERY, VISIBLE }

    private lateinit var uiWeb: WebView
    private lateinit var browserWeb: WebView
    private lateinit var chromeBar: LinearLayout
    private lateinit var chromeTitle: TextView

    private val handler = Handler(Looper.getMainLooper())

    private var browserMode = BrowserMode.NONE
    private var currentCategoryName = ""
    private var currentQuery = ""
    private var currentSearchUrl = ""
    private var discoveryToken = 0
    private var uiMode = "home"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(8, 9, 14)
        window.navigationBarColor = Color.rgb(5, 6, 9)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        // Local TopTop UI. This is the ONLY WebView that receives the Android JS bridge.
        uiWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configureWebView(settings)
            addJavascriptInterface(AndroidBridge(), "TopTopAndroid")
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
        }

        // Remote TikTok browser/discovery view.
        // IMPORTANT: no JavascriptInterface is exposed to TikTok pages.
        browserWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configureWebView(settings)
            webChromeClient = WebChromeClient()
            visibility = View.INVISIBLE
            webViewClient = object : WebViewClient() {

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    if (request == null || !request.isForMainFrame) return false
                    return handleRemoteNavigation(view, request.url)
                }

                @Deprecated("Deprecated in Java")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (url.isNullOrBlank()) return false
                    return handleRemoteNavigation(view, Uri.parse(url))
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (view == null || url.isNullOrBlank()) return

                    when (browserMode) {
                        BrowserMode.DISCOVERY -> {
                            val token = discoveryToken
                            handler.postDelayed({
                                if (token == discoveryToken && browserMode == BrowserMode.DISCOVERY) {
                                    harvestSearchResults(token, 0)
                                }
                            }, 1800)
                        }
                        BrowserMode.VISIBLE -> {
                            injectStayInsideTopTop(view)
                        }
                        BrowserMode.NONE -> Unit
                    }
                }
            }
        }

        CookieManager.getInstance().setAcceptThirdPartyCookies(uiWeb, true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(browserWeb, true)

        root.addView(
            uiWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        root.addView(
            browserWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(Color.argb(235, 8, 9, 14))
            visibility = View.GONE
        }

        val back = Button(this).apply {
            text = "‹"
            textSize = 28f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(46)
            minimumWidth = dp(46)
            setOnClickListener { returnToTopTopUi() }
        }

        chromeTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(5), 0, dp(8), 0)
            maxLines = 1
        }

        val refresh = Button(this).apply {
            text = "↻"
            textSize = 21f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(48)
            minimumWidth = dp(48)
            setOnClickListener { browserWeb.reload() }
        }

        chromeBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(46)))
        chromeBar.addView(chromeTitle, LinearLayout.LayoutParams(0, dp(46), 1f))
        chromeBar.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(46)))

        root.addView(
            chromeBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(58),
                Gravity.TOP
            )
        )

        setContentView(root)
        showHome()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(settings: WebSettings) {
        with(settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            userAgentString =
                "Mozilla/5.0 (Linux; Android 16; SM-S928B) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/140.0.0.0 Mobile Safari/537.36"
        }

        CookieManager.getInstance().setAcceptCookie(true)
    }

    private fun handleRemoteNavigation(view: WebView?, uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return true
        val raw = uri.toString()

        // TikTok mobile pages often try intent:// or tiktok:// to open the native app.
        // TopTop deliberately blocks those deep links.
        if (scheme == "intent") {
            try {
                val intent = Intent.parseUri(raw, Intent.URI_INTENT_SCHEME)
                val fallback = intent.getStringExtra("browser_fallback_url")
                if (!fallback.isNullOrBlank() && isTikTokWebUrl(fallback)) {
                    view?.loadUrl(fallback)
                }
            } catch (_: Exception) { }
            return true
        }

        if (scheme != "http" && scheme != "https") {
            // Blocks tiktok://, snssdk://, market:// and similar app-opening schemes.
            return true
        }

        val host = uri.host?.lowercase() ?: return true
        return if (isTikTokHost(host)) {
            false // keep TikTok web navigation inside this WebView
        } else {
            true  // block external navigation instead of handing it to another app
        }
    }

    private fun isTikTokWebUrl(url: String): Boolean {
        return try {
            val u = Uri.parse(url)
            (u.scheme == "https" || u.scheme == "http") &&
                isTikTokHost(u.host?.lowercase().orEmpty())
        } catch (_: Exception) {
            false
        }
    }

    private fun isTikTokHost(host: String): Boolean =
        host == "tiktok.com" ||
        host == "www.tiktok.com" ||
        host.endsWith(".tiktok.com") ||
        host.endsWith(".tiktokcdn.com") ||
        host.endsWith(".tiktokv.com")

    private fun injectStayInsideTopTop(view: WebView) {
        view.evaluateJavascript(
            """
            (function(){
              try {
                document.documentElement.style.background='#000';
                document.body.style.background='#000';
                document.body.style.paddingTop='58px';

                function neutralize(){
                  document.querySelectorAll('a[href]').forEach(function(a){
                    var h=(a.getAttribute('href')||'').toLowerCase();
                    if(h.startsWith('intent:') ||
                       h.startsWith('tiktok:') ||
                       h.startsWith('snssdk') ||
                       h.startsWith('market:')){
                      a.setAttribute('href','#');
                      a.onclick=function(e){e.preventDefault();return false;};
                    }
                  });

                  document.querySelectorAll('button,[role="button"]').forEach(function(b){
                    var t=(b.innerText||b.textContent||'').trim().toLowerCase();
                    if(t==='open app' ||
                       t==='open in app' ||
                       t==='mở ứng dụng' ||
                       t==='mở trong ứng dụng'){
                      b.style.display='none';
                    }
                  });
                }

                neutralize();
                if(!window.__toptopObserver){
                  window.__toptopObserver=new MutationObserver(neutralize);
                  window.__toptopObserver.observe(document.documentElement,{
                    subtree:true,childList:true,attributes:true,attributeFilter:['href']
                  });
                }
              } catch(e) {}
            })();
            """.trimIndent(),
            null
        )
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun discoverCategory(name: String, query: String) {
            runOnUiThread {
                discoveryToken += 1
                currentCategoryName = name
                currentQuery = query
                currentSearchUrl =
                    "https://www.tiktok.com/search/video?q=" +
                    URLEncoder.encode(query, "UTF-8")

                browserMode = BrowserMode.DISCOVERY
                browserWeb.visibility = View.INVISIBLE
                chromeBar.visibility = View.GONE
                uiWeb.visibility = View.VISIBLE
                browserWeb.loadUrl(currentSearchUrl)
            }
        }

        @JavascriptInterface
        fun openLive() {
            runOnUiThread {
                showRemoteInsideTopTop(
                    "LIVE",
                    "https://www.tiktok.com/live"
                )
            }
        }

        @JavascriptInterface
        fun openEmbeddedSearch(name: String, query: String) {
            runOnUiThread {
                val url =
                    "https://www.tiktok.com/search/video?q=" +
                    URLEncoder.encode(query, "UTF-8")
                showRemoteInsideTopTop(name, url)
            }
        }

        @JavascriptInterface
        fun cancelDiscovery() {
            runOnUiThread {
                discoveryToken += 1
                if (browserMode == BrowserMode.DISCOVERY) {
                    browserWeb.stopLoading()
                    browserWeb.loadUrl("about:blank")
                    browserMode = BrowserMode.NONE
                }
            }
        }

        @JavascriptInterface
        fun setUiMode(mode: String) {
            uiMode = mode.take(20)
        }

        @JavascriptInterface
        fun finishApp() {
            runOnUiThread { finish() }
        }
    }

    private fun showRemoteInsideTopTop(title: String, url: String) {
        discoveryToken += 1
        browserMode = BrowserMode.VISIBLE
        chromeTitle.text = "TopTop  •  $title"
        uiWeb.visibility = View.GONE
        browserWeb.visibility = View.VISIBLE
        chromeBar.visibility = View.VISIBLE
        browserWeb.loadUrl(url)
    }

    private fun returnToTopTopUi() {
        discoveryToken += 1
        browserWeb.stopLoading()
        browserWeb.loadUrl("about:blank")
        browserMode = BrowserMode.NONE
        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE
        uiWeb.visibility = View.VISIBLE
    }

    private fun harvestSearchResults(token: Int, attempt: Int) {
        if (
            token != discoveryToken ||
            browserMode != BrowserMode.DISCOVERY
        ) return

        val script = """
            (function(){
              try {
                var anchors=[].slice.call(document.querySelectorAll('a[href*="/video/"]'));
                var seen={};
                var out=[];

                anchors.forEach(function(a){
                  try {
                    var href=a.href||a.getAttribute('href')||'';
                    var m=href.match(/\/video\/(\d+)/);
                    if(!m || seen[m[1]]) return;
                    seen[m[1]]=1;

                    var card=a;
                    for(var i=0;i<4 && card && card.parentElement;i++){
                      var txt=(card.innerText||card.textContent||'').trim();
                      if(txt.length>15) break;
                      card=card.parentElement;
                    }

                    var img=a.querySelector('img');
                    if(!img && card) img=card.querySelector('img');

                    var title='';
                    if(a.getAttribute('title')) title=a.getAttribute('title');
                    if(!title && img && img.getAttribute('alt')) title=img.getAttribute('alt');
                    if(!title && card){
                      var lines=(card.innerText||card.textContent||'')
                        .split('\n')
                        .map(function(x){return x.trim();})
                        .filter(Boolean);
                      title=lines.slice(0,2).join(' • ');
                    }

                    var author='';
                    var am=href.match(/tiktok\.com\/@([^\/]+)\/video\//);
                    if(am) author='@'+decodeURIComponent(am[1]);

                    out.push({
                      id:m[1],
                      url:href,
                      title:(title||'TikTok video').slice(0,180),
                      author:author,
                      thumb:img?(img.currentSrc||img.src||''):''
                    });
                  } catch(e) {}
                });

                window.scrollBy(0, Math.max(window.innerHeight*2, 1400));
                return JSON.stringify(out.slice(0,36));
              } catch(e) {
                return '[]';
              }
            })();
        """.trimIndent()

        browserWeb.evaluateJavascript(script) { raw ->
            if (
                token != discoveryToken ||
                browserMode != BrowserMode.DISCOVERY
            ) return@evaluateJavascript

            val json = decodeJavascriptString(raw)
            val count = try {
                org.json.JSONArray(json).length()
            } catch (_: Exception) {
                0
            }

            if (count >= 6 || attempt >= 4) {
                deliverFeedToUi(
                    currentCategoryName,
                    currentQuery,
                    if (count > 0) json else "[]"
                )
                browserWeb.stopLoading()
                browserWeb.loadUrl("about:blank")
                browserMode = BrowserMode.NONE
            } else {
                handler.postDelayed({
                    if (token == discoveryToken && browserMode == BrowserMode.DISCOVERY) {
                        harvestSearchResults(token, attempt + 1)
                    }
                }, 1200)
            }
        }
    }

    private fun decodeJavascriptString(raw: String?): String {
        if (raw.isNullOrBlank() || raw == "null") return "[]"
        return try {
            val value = JSONTokener(raw).nextValue()
            when (value) {
                is String -> value
                else -> value.toString()
            }
        } catch (_: Exception) {
            "[]"
        }
    }

    private fun deliverFeedToUi(name: String, query: String, json: String) {
        uiWeb.visibility = View.VISIBLE
        chromeBar.visibility = View.GONE
        val js =
            "window.onFeedResults(" +
            JSONObject.quote(name) + "," +
            JSONObject.quote(query) + "," +
            JSONObject.quote(json) +
            ");"

        uiWeb.evaluateJavascript(js, null)
    }

    private fun showHome() {
        discoveryToken += 1
        browserMode = BrowserMode.NONE
        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE
        uiWeb.visibility = View.VISIBLE
        uiWeb.loadUrl("file:///android_asset/index.html")
        uiMode = "home"
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            browserMode == BrowserMode.VISIBLE -> {
                returnToTopTopUi()
            }
            browserMode == BrowserMode.DISCOVERY -> {
                discoveryToken += 1
                browserWeb.stopLoading()
                browserWeb.loadUrl("about:blank")
                browserMode = BrowserMode.NONE
                uiWeb.evaluateJavascript("window.returnHome && window.returnHome();", null)
            }
            uiMode != "home" -> {
                uiWeb.evaluateJavascript("window.returnHome && window.returnHome();", null)
            }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)

        uiWeb.loadUrl("about:blank")
        uiWeb.stopLoading()
        uiWeb.destroy()

        browserWeb.loadUrl("about:blank")
        browserWeb.stopLoading()
        browserWeb.destroy()

        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
