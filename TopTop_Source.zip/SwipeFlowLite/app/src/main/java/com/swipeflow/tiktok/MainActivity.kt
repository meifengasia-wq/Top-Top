package com.swipeflow.tiktok

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.URLEncoder

class MainActivity : Activity() {

    private enum class BrowserMode { NONE, LOGIN, VISIBLE }

    private lateinit var uiWeb: WebView
    private lateinit var browserWeb: WebView
    private lateinit var chromeBar: LinearLayout
    private lateinit var chromeTitle: TextView
    private lateinit var chromeAction: Button

    private val handler = Handler(Looper.getMainLooper())

    private var browserMode = BrowserMode.NONE
    private var uiMode = "home"
    private var categoryToken = 0
    private var autoOpenSearchResult = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(8, 9, 14)
        window.navigationBarColor = Color.rgb(5, 6, 9)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        uiWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configure(settings)
            addJavascriptInterface(AndroidBridge(), "TopTopAndroid")
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
        }

        browserWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configure(settings)
            visibility = View.INVISIBLE
            webChromeClient = WebChromeClient()

            webViewClient = object : WebViewClient() {

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    if (request == null || !request.isForMainFrame) return false
                    return handleNavigation(view, request.url)
                }

                @Deprecated("Deprecated in Java")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (url.isNullOrBlank()) return false
                    return handleNavigation(view, Uri.parse(url))
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (view == null || url.isNullOrBlank()) return

                    when (browserMode) {
                        BrowserMode.LOGIN -> {
                            injectStayInsideTopTop(view, addTopPadding = true)

                            if (
                                hasTikTokSessionCookie() &&
                                !url.contains("/login", ignoreCase = true)
                            ) {
                                handler.postDelayed({
                                    if (browserMode == BrowserMode.LOGIN) {
                                        finishLogin(showFailure = false)
                                    }
                                }, 650)
                            }
                        }

                        BrowserMode.VISIBLE -> {
                            injectStayInsideTopTop(view, addTopPadding = true)

                            if (
                                autoOpenSearchResult &&
                                url.contains("/search", ignoreCase = true)
                            ) {
                                val token = categoryToken
                                handler.postDelayed({
                                    if (
                                        token == categoryToken &&
                                        browserMode == BrowserMode.VISIBLE &&
                                        autoOpenSearchResult
                                    ) {
                                        openFirstVideoFromSearch(view, token, 0)
                                    }
                                }, 1700)
                            }
                        }

                        BrowserMode.NONE -> Unit
                    }
                }
            }
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(uiWeb, true)
            setAcceptThirdPartyCookies(browserWeb, true)
        }

        root.addView(
            uiWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        root.addView(
            browserWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(Color.argb(238, 8, 9, 14))
            visibility = View.GONE
        }

        val back = Button(this).apply {
            text = "‹"
            textSize = 28f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(46)
            minimumWidth = dp(46)
            setOnClickListener {
                if (browserMode == BrowserMode.LOGIN) {
                    returnToTopTop()
                    notifyLoginState()
                } else {
                    returnToTopTop()
                }
            }
        }

        chromeTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(5), 0, dp(8), 0)
            maxLines = 1
        }

        chromeAction = Button(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(66)
            minimumWidth = dp(66)
            setOnClickListener {
                if (browserMode == BrowserMode.LOGIN) {
                    finishLogin(showFailure = true)
                } else {
                    browserWeb.reload()
                }
            }
        }

        chromeBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(46)))
        chromeBar.addView(chromeTitle, LinearLayout.LayoutParams(0, dp(46), 1f))
        chromeBar.addView(chromeAction, LinearLayout.LayoutParams(dp(72), dp(46)))

        root.addView(
            chromeBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(58),
                Gravity.TOP
            )
        )

        setContentView(root)
        showHome()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(settings: WebSettings) {
        with(settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            userAgentString =
                "Mozilla/5.0 (Linux; Android 16; SM-S928B) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/140.0.0.0 Mobile Safari/537.36"
        }
    }

    private fun handleNavigation(view: WebView?, uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return true
        val raw = uri.toString()

        if (scheme == "intent") {
            try {
                val intent = Intent.parseUri(raw, Intent.URI_INTENT_SCHEME)
                val fallback = intent.getStringExtra("browser_fallback_url")
                if (!fallback.isNullOrBlank() && isAllowedWebUrl(fallback)) {
                    view?.loadUrl(fallback)
                }
            } catch (_: Exception) {
            }
            return true
        }

        if (scheme != "http" && scheme != "https") {
            // Blocks tiktok://, snssdk://, market:// and other app deep-links.
            return true
        }

        val host = uri.host?.lowercase().orEmpty()

        if (isTikTokHost(host)) return false

        if (browserMode == BrowserMode.LOGIN && isLoginProviderHost(host)) {
            return false
        }

        // Keep the whole experience inside TopTop.
        return true
    }

    private fun isAllowedWebUrl(url: String): Boolean {
        return try {
            val uri = Uri.parse(url)
            val host = uri.host?.lowercase().orEmpty()
            (uri.scheme == "http" || uri.scheme == "https") &&
                (
                    isTikTokHost(host) ||
                    (browserMode == BrowserMode.LOGIN && isLoginProviderHost(host))
                )
        } catch (_: Exception) {
            false
        }
    }

    private fun isTikTokHost(host: String): Boolean =
        host == "tiktok.com" ||
            host == "www.tiktok.com" ||
            host.endsWith(".tiktok.com") ||
            host.endsWith(".tiktokcdn.com") ||
            host.endsWith(".tiktokv.com")

    private fun isLoginProviderHost(host: String): Boolean =
        host == "accounts.google.com" ||
            host.endsWith(".google.com") ||
            host == "appleid.apple.com" ||
            host == "facebook.com" ||
            host == "www.facebook.com" ||
            host.endsWith(".facebook.com")

    private fun injectStayInsideTopTop(view: WebView, addTopPadding: Boolean) {
        val padding = if (addTopPadding) "58px" else "0px"

        view.evaluateJavascript(
            """
            (function(){
              try {
                document.documentElement.style.background='#000';
                document.body.style.background='#000';
                document.body.style.paddingTop='$padding';

                try {
                  window.open=function(url){
                    if(url){ window.location.href=url; }
                    return window;
                  };
                } catch(e) {}

                function patch(){
                  document.querySelectorAll('a[href]').forEach(function(a){
                    try {
                      a.setAttribute('target','_self');
                      var h=(a.getAttribute('href')||'').toLowerCase();

                      if(
                        h.startsWith('intent:') ||
                        h.startsWith('tiktok:') ||
                        h.startsWith('snssdk') ||
                        h.startsWith('market:')
                      ){
                        a.setAttribute('href','#');
                        a.onclick=function(e){
                          e.preventDefault();
                          return false;
                        };
                      }
                    } catch(e) {}
                  });

                  document.querySelectorAll('button,[role="button"]').forEach(function(b){
                    try {
                      var t=(b.innerText||b.textContent||'')
                        .trim()
                        .toLowerCase();

                      if(
                        t==='open app' ||
                        t==='open in app' ||
                        t==='use tiktok app' ||
                        t==='mở ứng dụng' ||
                        t==='mở trong ứng dụng' ||
                        t==='dùng ứng dụng tiktok'
                      ){
                        b.style.display='none';
                      }
                    } catch(e) {}
                  });
                }

                patch();

                if(!window.__topTopPatchObserver){
                  window.__topTopPatchObserver=new MutationObserver(patch);
                  window.__topTopPatchObserver.observe(
                    document.documentElement,
                    {
                      subtree:true,
                      childList:true,
                      attributes:true,
                      attributeFilter:['href','target']
                    }
                  );
                }
              } catch(e) {}
            })();
            """.trimIndent(),
            null
        )
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun isLoggedIn(): Boolean = hasTikTokSessionCookie()

        @JavascriptInterface
        fun openLoginEmail() {
            openLoginUrl("https://www.tiktok.com/login/phone-or-email/email")
        }

        @JavascriptInterface
        fun openLoginPhone() {
            openLoginUrl("https://www.tiktok.com/login/phone-or-email")
        }

        @JavascriptInterface
        fun openLogin() {
            openLoginUrl("https://www.tiktok.com/login")
        }

        @JavascriptInterface
        fun logout() {
            runOnUiThread {
                categoryToken += 1
                autoOpenSearchResult = false

                CookieManager.getInstance().removeAllCookies {
                    CookieManager.getInstance().flush()
                    browserWeb.clearCache(true)
                    browserWeb.clearHistory()
                    browserWeb.loadUrl("about:blank")
                    browserMode = BrowserMode.NONE
                    browserWeb.visibility = View.INVISIBLE
                    chromeBar.visibility = View.GONE
                    uiWeb.visibility = View.VISIBLE

                    uiWeb.evaluateJavascript(
                        "window.onTikTokLoginState && window.onTikTokLoginState(false);",
                        null
                    )
                }
            }
        }

        @JavascriptInterface
        fun openCategory(name: String, query: String) {
            runOnUiThread {
                if (!hasTikTokSessionCookie()) {
                    notifyLoginState()
                    return@runOnUiThread
                }

                categoryToken += 1
                autoOpenSearchResult = true

                val url =
                    "https://www.tiktok.com/search/video?q=" +
                        URLEncoder.encode(query, "UTF-8")

                showRemoteInsideTopTop(name, url)
            }
        }

        @JavascriptInterface
        fun openLive() {
            runOnUiThread {
                if (!hasTikTokSessionCookie()) {
                    notifyLoginState()
                    return@runOnUiThread
                }

                categoryToken += 1
                autoOpenSearchResult = false
                showRemoteInsideTopTop("LIVE", "https://www.tiktok.com/live")
            }
        }

        @JavascriptInterface
        fun setUiMode(mode: String) {
            uiMode = mode.take(20)
        }

        @JavascriptInterface
        fun finishApp() {
            runOnUiThread { finish() }
        }
    }

    private fun openLoginUrl(url: String) {
        runOnUiThread {
            categoryToken += 1
            autoOpenSearchResult = false
            browserMode = BrowserMode.LOGIN

            uiWeb.visibility = View.GONE
            browserWeb.visibility = View.VISIBLE
            chromeBar.visibility = View.VISIBLE

            chromeTitle.text = "TopTop  •  Đăng nhập TikTok"
            chromeAction.text = "Xong"

            browserWeb.loadUrl(url)
        }
    }

    private fun hasTikTokSessionCookie(): Boolean {
        val cookies = CookieManager.getInstance()
            .getCookie("https://www.tiktok.com")
            .orEmpty()
            .lowercase()

        if (cookies.isBlank()) return false

        val markers = listOf(
            "sessionid=",
            "sessionid_ss=",
            "sid_tt=",
            "sid_guard=",
            "uid_tt=",
            "uid_tt_ss="
        )

        return markers.any { cookies.contains(it) }
    }

    private fun finishLogin(showFailure: Boolean) {
        if (hasTikTokSessionCookie()) {
            CookieManager.getInstance().flush()

            browserWeb.stopLoading()
            browserWeb.loadUrl("about:blank")

            browserMode = BrowserMode.NONE
            browserWeb.visibility = View.INVISIBLE
            chromeBar.visibility = View.GONE
            uiWeb.visibility = View.VISIBLE

            uiWeb.evaluateJavascript(
                "window.onTikTokLoginState && window.onTikTokLoginState(true);",
                null
            )

            Toast.makeText(
                this,
                "Đã kết nối TikTok với TopTop.",
                Toast.LENGTH_SHORT
            ).show()
        } else if (showFailure) {
            Toast.makeText(
                this,
                "TopTop chưa thấy phiên đăng nhập. Hãy đăng nhập xong rồi bấm Xong.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun notifyLoginState() {
        uiWeb.visibility = View.VISIBLE
        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE

        uiWeb.evaluateJavascript(
            "window.onTikTokLoginState && window.onTikTokLoginState(${hasTikTokSessionCookie()});",
            null
        )
    }

    private fun showRemoteInsideTopTop(title: String, url: String) {
        browserMode = BrowserMode.VISIBLE

        chromeTitle.text = "TopTop  •  $title"
        chromeAction.text = "↻"

        uiWeb.visibility = View.GONE
        browserWeb.visibility = View.VISIBLE
        chromeBar.visibility = View.VISIBLE

        browserWeb.loadUrl(url)
    }

    private fun openFirstVideoFromSearch(view: WebView, token: Int, attempt: Int) {
        if (
            token != categoryToken ||
            browserMode != BrowserMode.VISIBLE ||
            !autoOpenSearchResult
        ) return

        val js = """
            (function(){
              try {
                var links=[].slice.call(
                  document.querySelectorAll('a[href*="/video/"]')
                );

                var a=links.find(function(x){
                  try {
                    var r=x.getBoundingClientRect();
                    return r.width>40 &&
                           r.height>40 &&
                           r.bottom>0 &&
                           r.top<window.innerHeight*2;
                  } catch(e) {
                    return false;
                  }
                }) || links[0];

                if(a && a.href){
                  a.setAttribute('target','_self');
                  window.location.assign(a.href);
                  return 'opened';
                }

                window.scrollBy(
                  0,
                  Math.max(window.innerHeight*1.5, 1000)
                );

                return 'none';
              } catch(e) {
                return 'error';
              }
            })();
        """.trimIndent()

        view.evaluateJavascript(js) { raw ->
            if (
                token != categoryToken ||
                browserMode != BrowserMode.VISIBLE ||
                !autoOpenSearchResult
            ) return@evaluateJavascript

            val result = try {
                JSONObject("{\"v\":$raw}").optString("v", raw ?: "")
            } catch (_: Exception) {
                raw.orEmpty()
            }

            if (result.contains("opened", ignoreCase = true)) {
                autoOpenSearchResult = false
                return@evaluateJavascript
            }

            if (attempt < 5) {
                handler.postDelayed({
                    openFirstVideoFromSearch(view, token, attempt + 1)
                }, 1000)
            } else {
                // Leave TikTok's search result screen visible.
                // The user can tap any result and still remains inside TopTop.
                autoOpenSearchResult = false

                Toast.makeText(
                    this,
                    "TikTok chưa tự mở video đầu tiên. Chạm một video trên màn hình để xem trong TopTop.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun returnToTopTop() {
        categoryToken += 1
        autoOpenSearchResult = false

        browserWeb.stopLoading()
        browserWeb.loadUrl("about:blank")

        browserMode = BrowserMode.NONE
        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE
        uiWeb.visibility = View.VISIBLE
    }

    private fun showHome() {
        categoryToken += 1
        autoOpenSearchResult = false
        browserMode = BrowserMode.NONE

        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE
        uiWeb.visibility = View.VISIBLE

        uiWeb.loadUrl("file:///android_asset/index.html")
        uiMode = "home"
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            browserMode == BrowserMode.LOGIN -> {
                returnToTopTop()
                notifyLoginState()
            }

            browserMode == BrowserMode.VISIBLE -> {
                if (browserWeb.canGoBack()) {
                    browserWeb.goBack()
                } else {
                    returnToTopTop()
                }
            }

            uiMode != "home" -> {
                uiWeb.evaluateJavascript(
                    "window.returnHome && window.returnHome();",
                    null
                )
            }

            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)

        uiWeb.loadUrl("about:blank")
        uiWeb.stopLoading()
        uiWeb.destroy()

        browserWeb.loadUrl("about:blank")
        browserWeb.stopLoading()
        browserWeb.destroy()

        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
