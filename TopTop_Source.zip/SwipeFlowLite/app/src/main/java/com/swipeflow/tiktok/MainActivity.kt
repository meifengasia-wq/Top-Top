package com.swipeflow.tiktok

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("toptop_state", MODE_PRIVATE) }
    private var pendingSharedText: String? = null
    private var pageReady = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 12, 18)
        window.navigationBarColor = Color.rgb(6, 7, 10)

        webView = WebView(this)
        setContentView(webView)
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = userAgentString + " TopTop/1.1"
        }
        webView.setBackgroundColor(Color.BLACK)
        webView.addJavascriptInterface(AndroidBridge(), "Android")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                deliverPendingShare()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val r = request ?: return false
                if (!r.isForMainFrame) return false
                val uri = r.url ?: return false
                val s = uri.toString()
                if (s.startsWith("file:///android_asset/")) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }
        pendingSharedText = extractSharedText(intent)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingSharedText = extractSharedText(intent)
        deliverPendingShare()
    }

    private fun extractSharedText(intent: Intent?): String? {
        if (intent?.action != Intent.ACTION_SEND || intent.type != "text/plain") return null
        return intent.getStringExtra(Intent.EXTRA_TEXT)?.trim()?.takeIf { it.isNotBlank() }
    }

    private fun deliverPendingShare() {
        if (!pageReady) return
        val text = pendingSharedText ?: return
        pendingSharedText = null
        runOnUiThread {
            webView.evaluateJavascript("window.receiveSharedText(${JSONObject.quote(text)});", null)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun loadState(): String {
            val current = prefs.getString("library_json", "") ?: ""
            if (current.isNotBlank()) return current
            // migrate v1.0 data if user installs over the older SwipeFlow build
            val legacy = getSharedPreferences("swipeflow_state", MODE_PRIVATE)
                .getString("library_json", "") ?: ""
            if (legacy.isNotBlank()) prefs.edit().putString("library_json", legacy).apply()
            return legacy
        }

        @JavascriptInterface
        fun saveState(json: String) {
            prefs.edit().putString("library_json", json).apply()
        }

        @JavascriptInterface
        fun resolveTikTok(raw: String, requestId: String) {
            Thread {
                val result = resolveTikTokInternal(raw)
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.onTikTokResolved(${JSONObject.quote(requestId)}, $result);",
                        null
                    )
                }
            }.start()
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun finishApp() {
            runOnUiThread { finish() }
        }
    }

    private fun resolveTikTokInternal(rawText: String): String {
        val out = JSONObject()
        return try {
            val sourceUrl = extractUrl(rawText)
                ?: throw IllegalArgumentException("Không tìm thấy link TikTok trong nội dung được chia sẻ.")

            val finalUrl = if (
                Regex("""/video/\d+""").containsMatchIn(sourceUrl) ||
                Regex("""/@[^/]+/live(?:[/?#]|$)""", RegexOption.IGNORE_CASE).containsMatchIn(sourceUrl)
            ) sourceUrl else followRedirects(sourceUrl)

            val liveUser = extractLiveUsername(finalUrl) ?: extractLiveUsername(sourceUrl)
            if (liveUser != null) {
                return out.put("ok", true)
                    .put("type", "live")
                    .put("url", finalUrl)
                    .put("author", liveUser)
                    .put("title", "LIVE @$liveUser")
                    .toString()
            }

            val id = Regex("""/video/(\d+)""").find(finalUrl)?.groupValues?.getOrNull(1)
                ?: Regex("""/video/(\d+)""").find(sourceUrl)?.groupValues?.getOrNull(1)
                ?: throw IllegalArgumentException(
                    "Chưa nhận ra video hoặc LIVE. Link ảnh/slideshow và một số link đặc biệt chưa được hỗ trợ."
                )

            var title = ""
            var author = ""
            var thumb = ""
            try {
                val encoded = URLEncoder.encode(finalUrl, "UTF-8")
                val meta = fetchJson("https://www.tiktok.com/oembed?url=$encoded")
                title = meta.optString("title", "")
                author = meta.optString("author_name", "")
                thumb = meta.optString("thumbnail_url", "")
            } catch (_: Exception) { }

            out.put("ok", true)
                .put("type", "video")
                .put("id", id)
                .put("url", finalUrl)
                .put("title", title)
                .put("author", author)
                .put("thumb", thumb)
                .toString()
        } catch (e: Exception) {
            out.put("ok", false)
                .put("error", e.message ?: "Không xử lý được link TikTok.")
                .toString()
        }
    }

    private fun extractLiveUsername(url: String): String? {
        return Regex("""/@([^/?#]+)/live(?:[/?#]|$)""", RegexOption.IGNORE_CASE)
            .find(url)?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }
    }

    private fun extractUrl(text: String): String? =
        Regex("""https?://[^\s]+""").find(text)?.value
            ?.trimEnd('.', ',', ')', ']', '}', '"', '\'')

    private fun followRedirects(raw: String): String {
        var current = raw
        repeat(7) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 12000
            conn.readTimeout = 12000
            conn.requestMethod = "GET"
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36"
            )
            conn.setRequestProperty("Accept-Language", "vi-VN,vi;q=0.9,en;q=0.7")
            val code = conn.responseCode
            val location = conn.getHeaderField("Location")
            conn.disconnect()
            if (code in 300..399 && !location.isNullOrBlank()) {
                current = URL(URL(current), location).toString()
            } else {
                return current
            }
        }
        return current
    }

    private fun fetchJson(url: String): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.requestMethod = "GET"
        conn.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36"
        )
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("TikTok metadata HTTP $code")
        return JSONObject(text)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack();", null)
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.loadUrl("about:blank")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
