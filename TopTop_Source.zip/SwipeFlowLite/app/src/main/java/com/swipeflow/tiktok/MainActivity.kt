package com.swipeflow.tiktok

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import java.net.URLEncoder

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var chromeBar: LinearLayout
    private lateinit var chromeTitle: TextView
    private val handler = Handler(Looper.getMainLooper())

    private var browsingTikTok = false
    private var currentCategoryName = ""
    private var currentSearchUrl = ""
    private var autoOpenAttempted = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(8, 9, 14)
        window.navigationBarColor = Color.rgb(5, 6, 9)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        webView = WebView(this)
        webView.setBackgroundColor(Color.BLACK)
        root.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(Color.argb(226, 8, 9, 14))
            visibility = View.GONE
        }

        val back = Button(this).apply {
            text = "‹"
            textSize = 28f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(46)
            minimumWidth = dp(46)
            setOnClickListener { showHome() }
        }

        chromeTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(5), 0, dp(8), 0)
            maxLines = 1
        }

        val refresh = Button(this).apply {
            text = "↻"
            textSize = 21f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(48)
            minimumWidth = dp(48)
            setOnClickListener { webView.reload() }
        }

        chromeBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(46)))
        chromeBar.addView(
            chromeTitle,
            LinearLayout.LayoutParams(0, dp(46), 1f)
        )
        chromeBar.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(46)))

        root.addView(
            chromeBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(58),
                Gravity.TOP
            )
        )

        setContentView(root)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString =
                "Mozilla/5.0 (Linux; Android 16; SM-S928B) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/140.0 Mobile Safari/537.36 TopTop/2.0"
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "TopTopAndroid")

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme ?: return false
                val host = uri.host?.lowercase() ?: ""

                if (scheme == "file") return false

                // Keep TikTok navigation inside TopTop.
                if (
                    host == "tiktok.com" ||
                    host == "www.tiktok.com" ||
                    host.endsWith(".tiktok.com") ||
                    host.endsWith(".tiktokcdn.com") ||
                    host.endsWith(".tiktokv.com")
                ) {
                    return false
                }

                // External destinations are handed to Android.
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } catch (_: Exception) {
                    false
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)

                if (!browsingTikTok) return

                // Add top padding so our TopTop bar doesn't cover TikTok controls.
                view?.evaluateJavascript(
                    """
                    (function(){
                      try {
                        document.documentElement.style.background='#000';
                        document.body.style.background='#000';
                        document.body.style.paddingTop='58px';
                      } catch(e) {}
                    })();
                    """.trimIndent(),
                    null
                )

                val u = url ?: return

                // Search results are only a discovery step.
                // Open the first visible public video automatically so the user
                // lands on TikTok's own immersive viewer and can continue browsing.
                if (
                    currentSearchUrl.isNotBlank() &&
                    u.startsWith("https://www.tiktok.com/search") &&
                    !autoOpenAttempted
                ) {
                    autoOpenAttempted = true
                    handler.postDelayed({
                        view?.evaluateJavascript(
                            """
                            (function(){
                              try {
                                var all=[].slice.call(document.querySelectorAll('a[href*="/video/"]'));
                                var a=all.find(function(x){
                                  var r=x.getBoundingClientRect();
                                  return r.width>20 && r.height>20;
                                }) || all[0];
                                if(a && a.href){ location.href=a.href; return 'opened'; }
                                return 'none';
                              } catch(e) { return 'error'; }
                            })();
                            """.trimIndent(),
                            null
                        )
                    }, 2200)
                }
            }
        }

        showHome()
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun openCategory(name: String, query: String) {
            runOnUiThread {
                currentCategoryName = name
                currentSearchUrl =
                    "https://www.tiktok.com/search/video?q=" +
                    URLEncoder.encode(query, "UTF-8")
                autoOpenAttempted = false
                browsingTikTok = true
                chromeTitle.text = "TopTop  •  $name"
                chromeBar.visibility = View.VISIBLE
                webView.loadUrl(currentSearchUrl)
            }
        }

        @JavascriptInterface
        fun openLive() {
            runOnUiThread {
                currentCategoryName = "LIVE"
                currentSearchUrl = ""
                autoOpenAttempted = true
                browsingTikTok = true
                chromeTitle.text = "TopTop  •  LIVE"
                chromeBar.visibility = View.VISIBLE
                webView.loadUrl("https://www.tiktok.com/live")
            }
        }

        @JavascriptInterface
        fun openTikTokHome() {
            runOnUiThread {
                currentCategoryName = "Khám phá"
                currentSearchUrl = ""
                autoOpenAttempted = true
                browsingTikTok = true
                chromeTitle.text = "TopTop"
                chromeBar.visibility = View.VISIBLE
                webView.loadUrl("https://www.tiktok.com/")
            }
        }
    }

    private fun showHome() {
        browsingTikTok = false
        currentSearchUrl = ""
        autoOpenAttempted = false
        chromeBar.visibility = View.GONE
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (browsingTikTok) {
            showHome()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        webView.loadUrl("about:blank")
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
