package com.swipeflow.tiktok

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder

class MainActivity : Activity() {

    private lateinit var homeWeb: WebView
    private lateinit var tiktokWeb: WebView
    private lateinit var topBar: LinearLayout
    private lateinit var topTitle: TextView

    private val handler = Handler(Looper.getMainLooper())

    private var showingTikTok = false
    private var navToken = 0
    private var currentTitle = ""
    private var currentTag = ""
    private var currentQuery = ""
    private var fallbackToSearchUsed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(7, 8, 12)
        window.navigationBarColor = Color.rgb(5, 6, 9)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        homeWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configure(settings)
            addJavascriptInterface(HomeBridge(), "TopTopAndroid")
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
        }

        tiktokWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configure(settings)
            visibility = View.INVISIBLE
            webChromeClient = WebChromeClient()

            webViewClient = object : WebViewClient() {

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    if (request == null || !request.isForMainFrame) return false
                    return handleNavigation(view, request.url)
                }

                @Deprecated("Deprecated in Java")
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    url: String?
                ): Boolean {
                    if (url.isNullOrBlank()) return false
                    return handleNavigation(view, Uri.parse(url))
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (view == null || url.isNullOrBlank() || !showingTikTok) return

                    injectKeepInside(view)

                    val token = navToken
                    if (
                        url.contains("/tag/", ignoreCase = true) ||
                        url.contains("/search", ignoreCase = true)
                    ) {
                        handler.postDelayed({
                            if (showingTikTok && token == navToken) {
                                tryOpenFirstVideo(view, token, 0)
                            }
                        }, 1700)
                    }
                }
            }
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(homeWeb, true)
            setAcceptThirdPartyCookies(tiktokWeb, true)
        }

        root.addView(
            homeWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        root.addView(
            tiktokWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(Color.argb(238, 7, 8, 12))
            visibility = View.GONE
        }

        val back = Button(this).apply {
            text = "‹"
            textSize = 28f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showHome() }
        }

        topTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(5), 0, dp(8), 0)
            maxLines = 1
        }

        val refresh = Button(this).apply {
            text = "↻"
            textSize = 21f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { tiktokWeb.reload() }
        }

        topBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(46)))
        topBar.addView(topTitle, LinearLayout.LayoutParams(0, dp(46), 1f))
        topBar.addView(refresh, LinearLayout.LayoutParams(dp(52), dp(46)))

        root.addView(
            topBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(58),
                Gravity.TOP
            )
        )

        setContentView(root)
        homeWeb.loadUrl("file:///android_asset/index.html")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(settings: WebSettings) {
        with(settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            userAgentString =
                "Mozilla/5.0 (Linux; Android 16; SM-S928B) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/140.0.0.0 Mobile Safari/537.36"
        }
    }

    private fun handleNavigation(view: WebView?, uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return true
        val raw = uri.toString()

        if (scheme == "intent") {
            try {
                val intent = Intent.parseUri(raw, Intent.URI_INTENT_SCHEME)
                val fallback = intent.getStringExtra("browser_fallback_url")
                if (!fallback.isNullOrBlank() && isTikTokHttpUrl(fallback)) {
                    view?.loadUrl(fallback)
                }
            } catch (_: Exception) {
            }
            return true
        }

        if (scheme != "http" && scheme != "https") {
            // Prevent tiktok://, snssdk://, market:// ... from leaving TopTop.
            return true
        }

        val host = uri.host?.lowercase().orEmpty()
        return !isTikTokHost(host)
    }

    private fun isTikTokHttpUrl(url: String): Boolean {
        return try {
            val u = Uri.parse(url)
            (u.scheme == "http" || u.scheme == "https") &&
                isTikTokHost(u.host?.lowercase().orEmpty())
        } catch (_: Exception) {
            false
        }
    }

    private fun isTikTokHost(host: String): Boolean =
        host == "tiktok.com" ||
            host == "www.tiktok.com" ||
            host.endsWith(".tiktok.com") ||
            host.endsWith(".tiktokcdn.com") ||
            host.endsWith(".tiktokv.com")

    private fun injectKeepInside(view: WebView) {
        view.evaluateJavascript(
            """
            (function(){
              try {
                document.documentElement.style.background='#000';
                document.body.style.paddingTop='58px';

                try {
                  window.open=function(url){
                    if(url){ window.location.href=url; }
                    return window;
                  };
                } catch(e) {}

                function patch(){
                  document.querySelectorAll('a[href]').forEach(function(a){
                    try {
                      a.setAttribute('target','_self');
                      var h=(a.getAttribute('href')||'').toLowerCase();
                      if(
                        h.startsWith('intent:') ||
                        h.startsWith('tiktok:') ||
                        h.startsWith('snssdk') ||
                        h.startsWith('market:')
                      ){
                        a.setAttribute('href','#');
                        a.onclick=function(e){
                          e.preventDefault();
                          return false;
                        };
                      }
                    } catch(e) {}
                  });

                  document.querySelectorAll('button,[role="button"]').forEach(function(b){
                    try {
                      var t=(b.innerText||b.textContent||'')
                        .trim().toLowerCase();
                      if(
                        t==='open app' ||
                        t==='open in app' ||
                        t==='use tiktok app' ||
                        t==='mở ứng dụng' ||
                        t==='mở trong ứng dụng' ||
                        t==='dùng ứng dụng tiktok'
                      ){
                        b.style.display='none';
                      }
                    } catch(e) {}
                  });
                }

                patch();

                if(!window.__toptopObserver){
                  window.__toptopObserver=new MutationObserver(patch);
                  window.__toptopObserver.observe(
                    document.documentElement,
                    {
                      subtree:true,
                      childList:true,
                      attributes:true,
                      attributeFilter:['href','target']
                    }
                  );
                }
              } catch(e) {}
            })();
            """.trimIndent(),
            null
        )
    }

    inner class HomeBridge {

        @JavascriptInterface
        fun openCategory(name: String, tag: String, query: String) {
            runOnUiThread {
                navToken += 1
                currentTitle = name
                currentTag = tag
                currentQuery = query
                fallbackToSearchUsed = false

                showTikTok(
                    name,
                    "https://www.tiktok.com/tag/" +
                        URLEncoder.encode(tag, "UTF-8")
                )
            }
        }

        @JavascriptInterface
        fun openLive() {
            runOnUiThread {
                navToken += 1
                currentTitle = "LIVE"
                currentTag = ""
                currentQuery = ""
                fallbackToSearchUsed = true
                showTikTok("LIVE", "https://www.tiktok.com/live")
            }
        }

        @JavascriptInterface
        fun openTikTokHome() {
            runOnUiThread {
                navToken += 1
                currentTitle = "TikTok"
                currentTag = ""
                currentQuery = ""
                fallbackToSearchUsed = true
                showTikTok("TikTok", "https://www.tiktok.com/")
            }
        }
    }

    private fun showTikTok(title: String, url: String) {
        showingTikTok = true
        topTitle.text = "TopTop  •  $title"
        homeWeb.visibility = View.GONE
        tiktokWeb.visibility = View.VISIBLE
        topBar.visibility = View.VISIBLE
        tiktokWeb.loadUrl(url)
    }

    private fun tryOpenFirstVideo(
        view: WebView,
        token: Int,
        attempt: Int
    ) {
        if (!showingTikTok || token != navToken) return

        val script = """
            (function(){
              try {
                var links=[].slice.call(
                  document.querySelectorAll('a[href*="/video/"]')
                );

                var a=links.find(function(x){
                  try {
                    var r=x.getBoundingClientRect();
                    return r.width>35 &&
                           r.height>35 &&
                           r.bottom>0 &&
                           r.top<window.innerHeight*2;
                  } catch(e) {
                    return false;
                  }
                }) || links[0];

                if(a && a.href){
                  a.setAttribute('target','_self');
                  window.location.assign(a.href);
                  return 'opened';
                }

                window.scrollBy(
                  0,
                  Math.max(window.innerHeight*1.3,900)
                );

                return 'none';
              } catch(e) {
                return 'error';
              }
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { raw ->
            if (!showingTikTok || token != navToken) return@evaluateJavascript

            val opened = raw?.contains("opened", ignoreCase = true) == true
            if (opened) return@evaluateJavascript

            if (attempt < 4) {
                handler.postDelayed({
                    tryOpenFirstVideo(view, token, attempt + 1)
                }, 950)
                return@evaluateJavascript
            }

            // Tag pages are often more public than Search. If tag produced no
            // video anchors, try Search once using the same category query.
            if (
                !fallbackToSearchUsed &&
                currentQuery.isNotBlank()
            ) {
                fallbackToSearchUsed = true

                val search =
                    "https://www.tiktok.com/search/video?q=" +
                        URLEncoder.encode(currentQuery, "UTF-8")

                tiktokWeb.loadUrl(search)
                return@evaluateJavascript
            }

            Toast.makeText(
                this,
                "TikTok không cho TopTop tự mở video. Trang TikTok vẫn đang nằm trong TopTop; hãy chạm một video nếu trang có kết quả.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun showHome() {
        navToken += 1
        showingTikTok = false
        fallbackToSearchUsed = false

        tiktokWeb.stopLoading()
        tiktokWeb.loadUrl("about:blank")
        tiktokWeb.visibility = View.INVISIBLE
        topBar.visibility = View.GONE

        homeWeb.visibility = View.VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingTikTok) {
            if (tiktokWeb.canGoBack()) {
                tiktokWeb.goBack()
            } else {
                showHome()
            }
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)

        homeWeb.loadUrl("about:blank")
        homeWeb.stopLoading()
        homeWeb.destroy()

        tiktokWeb.loadUrl("about:blank")
        tiktokWeb.stopLoading()
        tiktokWeb.destroy()

        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
