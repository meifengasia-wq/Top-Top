package com.swipeflow.tiktok

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONTokener
import org.json.JSONObject
import java.net.URLEncoder

class MainActivity : Activity() {

    private enum class BrowserMode { NONE, LOGIN, DISCOVERY, VISIBLE }

    private lateinit var uiWeb: WebView
    private lateinit var browserWeb: WebView
    private lateinit var chromeBar: LinearLayout
    private lateinit var chromeTitle: TextView
    private lateinit var chromeAction: Button

    private val handler = Handler(Looper.getMainLooper())
    private val authPrefs by lazy { getSharedPreferences("toptop_auth", MODE_PRIVATE) }

    private var browserMode = BrowserMode.NONE
    private var currentCategoryName = ""
    private var currentQuery = ""
    private var currentSearchUrl = ""
    private var discoveryToken = 0
    private var uiMode = "home"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(8, 9, 14)
        window.navigationBarColor = Color.rgb(5, 6, 9)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        uiWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configureWebSettings(settings)
            addJavascriptInterface(AndroidBridge(), "TopTopAndroid")
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
        }

        browserWeb = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            configureWebSettings(settings)
            webChromeClient = WebChromeClient()
            visibility = View.INVISIBLE
            webViewClient = object : WebViewClient() {

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    if (request == null || !request.isForMainFrame) return false
                    return handleRemoteNavigation(view, request.url)
                }

                @Deprecated("Deprecated in Java")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (url.isNullOrBlank()) return false
                    return handleRemoteNavigation(view, Uri.parse(url))
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (view == null || url.isNullOrBlank()) return

                    when (browserMode) {
                        BrowserMode.LOGIN -> {
                            injectNoNativeApp(view)

                            // When TikTok has created a real authenticated session,
                            // finish onboarding automatically.
                            if (
                                hasTikTokSessionCookie() &&
                                !url.contains("/login", ignoreCase = true)
                            ) {
                                handler.postDelayed({
                                    if (browserMode == BrowserMode.LOGIN) {
                                        completeLogin(showFailure = false)
                                    }
                                }, 700)
                            }
                        }

                        BrowserMode.DISCOVERY -> {
                            injectNoNativeApp(view)
                            val token = discoveryToken
                            handler.postDelayed({
                                if (
                                    token == discoveryToken &&
                                    browserMode == BrowserMode.DISCOVERY
                                ) {
                                    harvestSearchResults(token, 0)
                                }
                            }, 1800)
                        }

                        BrowserMode.VISIBLE -> injectStayInsideTopTop(view)
                        BrowserMode.NONE -> Unit
                    }
                }
            }
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(uiWeb, true)
            setAcceptThirdPartyCookies(browserWeb, true)
        }

        root.addView(
            uiWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        root.addView(
            browserWeb,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(Color.argb(236, 8, 9, 14))
            visibility = View.GONE
        }

        val back = Button(this).apply {
            text = "‹"
            textSize = 28f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(46)
            minimumWidth = dp(46)
            setOnClickListener {
                when (browserMode) {
                    BrowserMode.LOGIN -> {
                        returnToTopTopUi()
                        notifyLoginState()
                    }
                    else -> returnToTopTopUi()
                }
            }
        }

        chromeTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(5), 0, dp(8), 0)
            maxLines = 1
        }

        chromeAction = Button(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            minWidth = dp(62)
            minimumWidth = dp(62)
            setOnClickListener {
                if (browserMode == BrowserMode.LOGIN) {
                    completeLogin(showFailure = true)
                } else {
                    browserWeb.reload()
                }
            }
        }

        chromeBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(46)))
        chromeBar.addView(chromeTitle, LinearLayout.LayoutParams(0, dp(46), 1f))
        chromeBar.addView(chromeAction, LinearLayout.LayoutParams(dp(70), dp(46)))

        root.addView(
            chromeBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(58),
                Gravity.TOP
            )
        )

        setContentView(root)
        showHome()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebSettings(settings: WebSettings) {
        with(settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            userAgentString =
                "Mozilla/5.0 (Linux; Android 16; SM-S928B) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/140.0.0.0 Mobile Safari/537.36"
        }
    }

    private fun handleRemoteNavigation(view: WebView?, uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return true
        val raw = uri.toString()

        // Do not let TikTok launch the native TikTok app.
        if (scheme == "intent") {
            try {
                val intent = Intent.parseUri(raw, Intent.URI_INTENT_SCHEME)
                val fallback = intent.getStringExtra("browser_fallback_url")
                if (!fallback.isNullOrBlank() && isAllowedWebUrl(fallback)) {
                    view?.loadUrl(fallback)
                }
            } catch (_: Exception) { }
            return true
        }

        if (scheme != "http" && scheme != "https") {
            // Blocks tiktok://, snssdk://, market://, etc.
            return true
        }

        val host = uri.host?.lowercase().orEmpty()

        if (isTikTokHost(host)) return false

        // During the login screen we allow a few common identity-provider hosts
        // to stay inside the same WebView. Some providers may still refuse
        // embedded WebViews; phone/email login remains the most reliable.
        if (browserMode == BrowserMode.LOGIN && isLoginProviderHost(host)) {
            return false
        }

        // Do not hand remote links to another app.
        return true
    }

    private fun isAllowedWebUrl(url: String): Boolean {
        return try {
            val u = Uri.parse(url)
            val host = u.host?.lowercase().orEmpty()
            (u.scheme == "https" || u.scheme == "http") &&
                (isTikTokHost(host) ||
                    (browserMode == BrowserMode.LOGIN && isLoginProviderHost(host)))
        } catch (_: Exception) {
            false
        }
    }

    private fun isTikTokHost(host: String): Boolean =
        host == "tiktok.com" ||
            host == "www.tiktok.com" ||
            host.endsWith(".tiktok.com") ||
            host.endsWith(".tiktokcdn.com") ||
            host.endsWith(".tiktokv.com")

    private fun isLoginProviderHost(host: String): Boolean =
        host == "accounts.google.com" ||
            host.endsWith(".google.com") ||
            host == "appleid.apple.com" ||
            host == "facebook.com" ||
            host == "www.facebook.com" ||
            host.endsWith(".facebook.com")

    private fun injectNoNativeApp(view: WebView) {
        view.evaluateJavascript(
            """
            (function(){
              try {
                function neutralize(){
                  document.querySelectorAll('a[href]').forEach(function(a){
                    var h=(a.getAttribute('href')||'').toLowerCase();
                    if(h.startsWith('intent:') ||
                       h.startsWith('tiktok:') ||
                       h.startsWith('snssdk') ||
                       h.startsWith('market:')){
                      a.setAttribute('href','#');
                      a.onclick=function(e){e.preventDefault();return false;};
                    }
                  });

                  document.querySelectorAll('button,[role="button"]').forEach(function(b){
                    var t=(b.innerText||b.textContent||'').trim().toLowerCase();
                    if(t==='open app' ||
                       t==='open in app' ||
                       t==='mở ứng dụng' ||
                       t==='mở trong ứng dụng'){
                      b.style.display='none';
                    }
                  });
                }
                neutralize();
                if(!window.__toptopNoAppObserver){
                  window.__toptopNoAppObserver=new MutationObserver(neutralize);
                  window.__toptopNoAppObserver.observe(document.documentElement,{
                    subtree:true,childList:true,attributes:true,attributeFilter:['href']
                  });
                }
              } catch(e) {}
            })();
            """.trimIndent(),
            null
        )
    }

    private fun injectStayInsideTopTop(view: WebView) {
        injectNoNativeApp(view)
        view.evaluateJavascript(
            """
            (function(){
              try {
                document.documentElement.style.background='#000';
                document.body.style.background='#000';
                document.body.style.paddingTop='58px';
              } catch(e) {}
            })();
            """.trimIndent(),
            null
        )
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun isLoggedIn(): Boolean = isLoggedInInternal()

        @JavascriptInterface
        fun openLogin() {
            runOnUiThread {
                browserMode = BrowserMode.LOGIN
                browserWeb.visibility = View.VISIBLE
                uiWeb.visibility = View.GONE
                chromeBar.visibility = View.VISIBLE
                chromeTitle.text = "TopTop  •  Đăng nhập TikTok"
                chromeAction.text = "Xong"
                browserWeb.loadUrl("https://www.tiktok.com/login")
            }
        }

        @JavascriptInterface
        fun logout() {
            runOnUiThread {
                authPrefs.edit().putBoolean("verified_login", false).apply()
                CookieManager.getInstance().removeAllCookies {
                    CookieManager.getInstance().flush()
                    browserWeb.clearCache(true)
                    browserWeb.clearHistory()
                    browserWeb.loadUrl("about:blank")
                    browserMode = BrowserMode.NONE
                    uiWeb.visibility = View.VISIBLE
                    browserWeb.visibility = View.INVISIBLE
                    chromeBar.visibility = View.GONE
                    uiWeb.evaluateJavascript(
                        "window.onTikTokLoginState && window.onTikTokLoginState(false);",
                        null
                    )
                }
            }
        }

        @JavascriptInterface
        fun discoverCategory(name: String, query: String) {
            runOnUiThread {
                if (!isLoggedInInternal()) {
                    notifyLoginState()
                    return@runOnUiThread
                }

                discoveryToken += 1
                currentCategoryName = name
                currentQuery = query
                currentSearchUrl =
                    "https://www.tiktok.com/search/video?q=" +
                        URLEncoder.encode(query, "UTF-8")

                browserMode = BrowserMode.DISCOVERY
                browserWeb.visibility = View.INVISIBLE
                chromeBar.visibility = View.GONE
                uiWeb.visibility = View.VISIBLE
                browserWeb.loadUrl(currentSearchUrl)
            }
        }

        @JavascriptInterface
        fun openLive() {
            runOnUiThread {
                if (!isLoggedInInternal()) {
                    notifyLoginState()
                    return@runOnUiThread
                }
                showRemoteInsideTopTop(
                    "LIVE",
                    "https://www.tiktok.com/live"
                )
            }
        }

        @JavascriptInterface
        fun openEmbeddedSearch(name: String, query: String) {
            runOnUiThread {
                if (!isLoggedInInternal()) {
                    notifyLoginState()
                    return@runOnUiThread
                }
                val url =
                    "https://www.tiktok.com/search/video?q=" +
                        URLEncoder.encode(query, "UTF-8")
                showRemoteInsideTopTop(name, url)
            }
        }

        @JavascriptInterface
        fun cancelDiscovery() {
            runOnUiThread {
                discoveryToken += 1
                if (browserMode == BrowserMode.DISCOVERY) {
                    browserWeb.stopLoading()
                    browserWeb.loadUrl("about:blank")
                    browserMode = BrowserMode.NONE
                }
            }
        }

        @JavascriptInterface
        fun setUiMode(mode: String) {
            uiMode = mode.take(20)
        }

        @JavascriptInterface
        fun finishApp() {
            runOnUiThread { finish() }
        }
    }

    private fun hasTikTokSessionCookie(): Boolean {
        val cookies = CookieManager.getInstance()
            .getCookie("https://www.tiktok.com")
            .orEmpty()
            .lowercase()

        if (cookies.isBlank()) return false

        val sessionMarkers = listOf(
            "sessionid=",
            "sessionid_ss=",
            "sid_tt=",
            "sid_guard=",
            "uid_tt=",
            "uid_tt_ss="
        )
        return sessionMarkers.any { cookies.contains(it) }
    }

    private fun isLoggedInInternal(): Boolean {
        val cookieSession = hasTikTokSessionCookie()
        if (cookieSession) {
            authPrefs.edit().putBoolean("verified_login", true).apply()
            return true
        }
        return false
    }

    private fun completeLogin(showFailure: Boolean) {
        if (hasTikTokSessionCookie()) {
            authPrefs.edit().putBoolean("verified_login", true).apply()
            CookieManager.getInstance().flush()
            browserWeb.stopLoading()
            browserWeb.loadUrl("about:blank")
            browserMode = BrowserMode.NONE
            browserWeb.visibility = View.INVISIBLE
            chromeBar.visibility = View.GONE
            uiWeb.visibility = View.VISIBLE
            uiWeb.evaluateJavascript(
                "window.onTikTokLoginState && window.onTikTokLoginState(true);",
                null
            )
            Toast.makeText(
                this,
                "Đã kết nối phiên TikTok với TopTop.",
                Toast.LENGTH_SHORT
            ).show()
        } else if (showFailure) {
            Toast.makeText(
                this,
                "TopTop chưa thấy phiên đăng nhập. Hãy đăng nhập xong trên TikTok rồi bấm Xong.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun notifyLoginState() {
        uiWeb.visibility = View.VISIBLE
        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE
        uiWeb.evaluateJavascript(
            "window.onTikTokLoginState && window.onTikTokLoginState(${isLoggedInInternal()});",
            null
        )
    }

    private fun showRemoteInsideTopTop(title: String, url: String) {
        discoveryToken += 1
        browserMode = BrowserMode.VISIBLE
        chromeTitle.text = "TopTop  •  $title"
        chromeAction.text = "↻"
        uiWeb.visibility = View.GONE
        browserWeb.visibility = View.VISIBLE
        chromeBar.visibility = View.VISIBLE
        browserWeb.loadUrl(url)
    }

    private fun returnToTopTopUi() {
        discoveryToken += 1
        browserWeb.stopLoading()
        browserWeb.loadUrl("about:blank")
        browserMode = BrowserMode.NONE
        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE
        uiWeb.visibility = View.VISIBLE
    }

    private fun harvestSearchResults(token: Int, attempt: Int) {
        if (
            token != discoveryToken ||
            browserMode != BrowserMode.DISCOVERY
        ) return

        val script = """
            (function(){
              try {
                var anchors=[].slice.call(
                  document.querySelectorAll('a[href*="/video/"]')
                );
                var seen={};
                var out=[];

                anchors.forEach(function(a){
                  try {
                    var href=a.href||a.getAttribute('href')||'';
                    var m=href.match(/\/video\/(\d+)/);
                    if(!m || seen[m[1]]) return;
                    seen[m[1]]=1;

                    var card=a;
                    for(var i=0;i<5 && card && card.parentElement;i++){
                      var txt=(card.innerText||card.textContent||'').trim();
                      if(txt.length>20) break;
                      card=card.parentElement;
                    }

                    var img=a.querySelector('img');
                    if(!img && card) img=card.querySelector('img');

                    var title='';
                    if(a.getAttribute('title')) title=a.getAttribute('title');
                    if(!title && img && img.getAttribute('alt')){
                      title=img.getAttribute('alt');
                    }
                    if(!title && card){
                      var lines=(card.innerText||card.textContent||'')
                        .split('\n')
                        .map(function(x){return x.trim();})
                        .filter(Boolean);
                      title=lines.slice(0,2).join(' • ');
                    }

                    var author='';
                    var am=href.match(/tiktok\.com\/@([^\/]+)\/video\//);
                    if(am) author='@'+decodeURIComponent(am[1]);

                    out.push({
                      id:m[1],
                      url:href,
                      title:(title||'TikTok video').slice(0,180),
                      author:author,
                      thumb:img?(img.currentSrc||img.src||''):''
                    });
                  } catch(e) {}
                });

                window.scrollBy(0,Math.max(window.innerHeight*2,1500));
                return JSON.stringify(out.slice(0,40));
              } catch(e) {
                return '[]';
              }
            })();
        """.trimIndent()

        browserWeb.evaluateJavascript(script) { raw ->
            if (
                token != discoveryToken ||
                browserMode != BrowserMode.DISCOVERY
            ) return@evaluateJavascript

            val json = decodeJavascriptString(raw)
            val count = try {
                JSONArray(json).length()
            } catch (_: Exception) {
                0
            }

            if (count >= 6 || attempt >= 5) {
                deliverFeedToUi(
                    currentCategoryName,
                    currentQuery,
                    if (count > 0) json else "[]"
                )
                browserWeb.stopLoading()
                browserWeb.loadUrl("about:blank")
                browserMode = BrowserMode.NONE
            } else {
                handler.postDelayed({
                    if (
                        token == discoveryToken &&
                        browserMode == BrowserMode.DISCOVERY
                    ) {
                        harvestSearchResults(token, attempt + 1)
                    }
                }, 1250)
            }
        }
    }

    private fun decodeJavascriptString(raw: String?): String {
        if (raw.isNullOrBlank() || raw == "null") return "[]"
        return try {
            val value = JSONTokener(raw).nextValue()
            when (value) {
                is String -> value
                else -> value.toString()
            }
        } catch (_: Exception) {
            "[]"
        }
    }

    private fun deliverFeedToUi(name: String, query: String, json: String) {
        uiWeb.visibility = View.VISIBLE
        chromeBar.visibility = View.GONE

        val js =
            "window.onFeedResults(" +
                JSONObject.quote(name) + "," +
                JSONObject.quote(query) + "," +
                JSONObject.quote(json) +
                ");"

        uiWeb.evaluateJavascript(js, null)
    }

    private fun showHome() {
        discoveryToken += 1
        browserMode = BrowserMode.NONE
        browserWeb.visibility = View.INVISIBLE
        chromeBar.visibility = View.GONE
        uiWeb.visibility = View.VISIBLE
        uiWeb.loadUrl("file:///android_asset/index.html")
        uiMode = "home"
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            browserMode == BrowserMode.LOGIN -> {
                returnToTopTopUi()
                notifyLoginState()
            }
            browserMode == BrowserMode.VISIBLE -> returnToTopTopUi()
            browserMode == BrowserMode.DISCOVERY -> {
                discoveryToken += 1
                browserWeb.stopLoading()
                browserWeb.loadUrl("about:blank")
                browserMode = BrowserMode.NONE
                uiWeb.evaluateJavascript(
                    "window.returnHome && window.returnHome();",
                    null
                )
            }
            uiMode != "home" -> {
                uiWeb.evaluateJavascript(
                    "window.returnHome && window.returnHome();",
                    null
                )
            }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)

        uiWeb.loadUrl("about:blank")
        uiWeb.stopLoading()
        uiWeb.destroy()

        browserWeb.loadUrl("about:blank")
        browserWeb.stopLoading()
        browserWeb.destroy()

        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
